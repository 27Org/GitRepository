Ext.define('app.view.plugin.Paging', {
    extend: 'Ext.panel.Panel'
});